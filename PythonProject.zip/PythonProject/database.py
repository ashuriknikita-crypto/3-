import sqlite3


class Database:
    def __init__(self, path='trends.db'):
        self.path = path
        self.conn = None
        self.cursor = None

    def connect(self):
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.cursor.execute("PRAGMA journal_mode=WAL")
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            time REAL, source TEXT, object_id INTEGER, value REAL
        )''')
        self.conn.commit()

    def insert(self, time, source, object_id, value):
        self.cursor.execute(
            'INSERT INTO data (time, source, object_id, value) VALUES (?, ?, ?, ?)',
            (time, source, object_id, value)
        )

    def commit(self):
        self.conn.commit()

    def close(self):
        if self.conn:
            self.conn.close()