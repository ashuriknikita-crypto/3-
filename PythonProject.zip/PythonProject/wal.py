import json
import os


class WAL:
    def __init__(self, path='data.wal'):
        self.path = path

    def write(self, entry):
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')

    def migrate(self, db):
        if not os.path.exists(self.path):
            return 0
        count = 0
        with open(self.path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    db.insert(data['time'], data['source'], data['object_id'], data['value'])
                    count += 1
                except:
                    pass
        db.commit()
        with open(self.path, 'w', encoding='utf-8') as f:
            pass
        return count

    def save_json(self, values, path='last.json'):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(values, f)

    def load_json(self, path='last.json'):
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}