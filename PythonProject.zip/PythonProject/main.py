import time
import sys
from config import create_objects
from state import state
from database import Database
from wal import WAL
from sources import Sources
from server import start_server


def main():

    objects = create_objects()
    state.set_objects(objects)

    db = Database()
    db.connect()

    wal = WAL()


    last_values = wal.load_json()
    state.set_last_values(last_values)

    migrated = wal.migrate(db)


    sources = Sources(objects, wal)

    start_server(8080)

    print("\n СИСТЕМА ЗАПУЩЕНА")
    print(" Откройте http://localhost:8080")


    try:
        iteration = 0
        while True:
            iteration += 1

            c1 = sum(1 for _ in sources.generate_rank())
            c2 = sum(1 for _ in sources.generate_mmr())
            c3 = sum(1 for _ in sources.generate_hero())
            c4 = sum(1 for _ in sources.generate_hours())


            state.set_stats(c1, c2, c3, c4)

            if iteration % 10 == 0:
                migrated = wal.migrate(db)
                wal.save_json(state.get_last_values())
                print(f" [{time.strftime('%H:%M:%S')}]  {c1 + c2 + c3 + c4} записей |  {migrated} мигрировано")

            time.sleep(1)

    except KeyboardInterrupt:
        print("\n Остановка...")
        wal.migrate(db)
        wal.save_json(state.get_last_values())
        db.close()
        print("Сохранено.")


if __name__ == "__main__":
    main()