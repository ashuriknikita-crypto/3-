HEROES = {
    1: {"ru": "Анти-Маг", "en": "antimage"},
    2: {"ru": "Акс", "en": "axe"},
    3: {"ru": "Бэйн", "en": "bane"},
    4: {"ru": "Бладсикер", "en": "bloodseeker"},
    5: {"ru": "Кристальная Дева", "en": "crystal_maiden"},
    6: {"ru": "Дроу Рейнджер", "en": "drow_ranger"},
    7: {"ru": "Землетряс", "en": "earthshaker"},
    8: {"ru": "Джаггернаут", "en": "juggernaut"},
    9: {"ru": "Мирана", "en": "mirana"},
    10: {"ru": "Морфлинг", "en": "morphling"},
    11: {"ru": "Невермор", "en": "shadow_fiend"},
    12: {"ru": "Фантомный Копейщик", "en": "phantom_lancer"},
    13: {"ru": "Пак", "en": "puck"},
    14: {"ru": "Пудж", "en": "pudge"},
    15: {"ru": "Разор", "en": "razor"},
    16: {"ru": "Песочный Король", "en": "sand_king"},
    17: {"ru": "Шторм", "en": "storm_spirit"},
    18: {"ru": "Свен", "en": "sven"},
    19: {"ru": "Тини", "en": "tiny"},
    20: {"ru": "Мстительный Дух", "en": "vengefulspirit"},
    74: {"ru": "Инвокер", "en": "invoker"},
    109: {"ru": "Техис", "en": "techies"},
    129: {"ru": "Марс", "en": "mars"}
}

def get_rank_name(rank):
    rank = int(rank)
    if rank <= 10: return f"Герой {rank}"
    elif rank <= 20: return f"Страж {rank - 10}"
    elif rank <= 30: return f"Рыцарь {rank - 20}"
    elif rank <= 40: return f"Властелин {rank - 30}"
    elif rank <= 50: return f"Легенда {rank - 40}"
    elif rank <= 60: return f"Древний {rank - 50}"
    elif rank <= 70: return f"Божество {rank - 60}"
    else: return f"Бессмертный {rank - 70}"

def get_hero_name(hero_id):
    hero_id = int(hero_id)
    if hero_id in HEROES:
        return HEROES[hero_id]["ru"]
    return f"Герой #{hero_id}"

def get_hero_image(hero_id):
    hero_id = int(hero_id)
    if hero_id in HEROES:
        return f"https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/{HEROES[hero_id]['en']}.png"
    return "https://cdn.cloudflare.steamstatic.com/apps/dota2/images/dota_react/heroes/antimage.png"

def get_rank_image(rank):
    rank = int(rank)
    urls = {
        10: "https://liquipedia.net/commons/images/thumb/0/07/Herald_rank_icon.png/100px-Herald_rank_icon.png",
        20: "https://liquipedia.net/commons/images/thumb/2/2e/Guardian_rank_icon.png/100px-Guardian_rank_icon.png",
        30: "https://liquipedia.net/commons/images/thumb/9/9c/Crusader_rank_icon.png/100px-Crusader_rank_icon.png",
        40: "https://liquipedia.net/commons/images/thumb/2/27/Archon_rank_icon.png/100px-Archon_rank_icon.png",
        50: "https://liquipedia.net/commons/images/thumb/f/f6/Legend_rank_icon.png/100px-Legend_rank_icon.png",
        60: "https://liquipedia.net/commons/images/thumb/0/04/Ancient_rank_icon.png/100px-Ancient_rank_icon.png",
        70: "https://liquipedia.net/commons/images/thumb/9/96/Divine_rank_icon.png/100px-Divine_rank_icon.png",
        80: "https://liquipedia.net/commons/images/thumb/8/82/Immortal_rank_icon.png/100px-Immortal_rank_icon.png"
    }
    for threshold in sorted(urls.keys()):
        if rank <= threshold:
            return urls[threshold]
    return urls[80]

def create_objects():
    objects = {}
    for i in range(1000):
        if i % 4 == 0: objects[i] = 'rank'
        elif i % 4 == 1: objects[i] = 'mmr'
        elif i % 4 == 2: objects[i] = 'hero'
        else: objects[i] = 'hours'
    return objects