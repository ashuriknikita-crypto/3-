import random
import math
import time


class Sources:
    def __init__(self, objects, wal):
        self.objects = objects
        self.wal = wal
        self.base_rank = 40
        self.tick_hours = 0

    def generate_rank(self):
        count = random.randint(100, 600)
        for _ in range(count):
            obj_id = random.randint(0, 999)
            obj_type = self.objects[obj_id]
            self.base_rank += random.uniform(-2, 2)
            val = self.base_rank
            if obj_type == 'rank':
                val = max(1, min(80, int(val)))
            elif obj_type == 'mmr':
                val = int(val * 100)
            elif obj_type == 'hero':
                val = random.randint(1, 124)
            elif obj_type == 'hours':
                val = float(abs(val) * 10)
            self.wal.write({'time': time.time(), 'source': 'rank', 'object_id': obj_id, 'value': val})
            yield obj_id, val
        return count

    def generate_mmr(self):
        count = random.randint(100, 600)
        for _ in range(count):
            obj_id = random.randint(0, 999)
            obj_type = self.objects[obj_id]
            val = random.gauss(5000, 1500)
            if obj_type == 'rank':
                val = max(1, min(80, int(val / 100)))
            elif obj_type == 'mmr':
                val = max(0, int(val))
            elif obj_type == 'hero':
                val = random.randint(1, 124)
            elif obj_type == 'hours':
                val = float(max(0, val / 10))
            self.wal.write({'time': time.time(), 'source': 'mmr', 'object_id': obj_id, 'value': val})
            yield obj_id, val
        return count

    def generate_hero(self):
        count = random.randint(100, 600)
        for _ in range(count):
            obj_id = random.randint(0, 999)
            obj_type = self.objects[obj_id]
            val = 74 if random.random() > 0.05 else random.uniform(1, 124)
            if obj_type == 'rank':
                val = random.randint(1, 80)
            elif obj_type == 'mmr':
                val = random.randint(0, 15000)
            elif obj_type == 'hero':
                val = int(val)
            elif obj_type == 'hours':
                val = float(random.uniform(0, 20000))
            self.wal.write({'time': time.time(), 'source': 'hero', 'object_id': obj_id, 'value': val})
            yield obj_id, val
        return count

    def generate_hours(self):
        count = random.randint(100, 600)
        for _ in range(count):
            obj_id = random.randint(0, 999)
            obj_type = self.objects[obj_id]
            val = self.tick_hours * 0.5 + math.sin(self.tick_hours * 0.1) * 100
            self.tick_hours += 1
            if obj_type == 'rank':
                val = max(1, min(80, int(val / 100)))
            elif obj_type == 'mmr':
                val = max(0, int(val * 10))
            elif obj_type == 'hero':
                val = random.randint(1, 124)
            elif obj_type == 'hours':
                val = float(max(0, val))
            self.wal.write({'time': time.time(), 'source': 'hours', 'object_id': obj_id, 'value': val})
            yield obj_id, val
        return count