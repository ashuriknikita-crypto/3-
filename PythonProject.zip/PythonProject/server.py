from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import threading
from config import get_rank_name, get_hero_name, get_hero_image, get_rank_image
from state import state


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(self._html().encode('utf-8'))
        elif self.path == '/api/stats':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(state.get_stats()).encode('utf-8'))
        elif self.path == '/api/data':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'html': self._table()}).encode('utf-8'))

    def log_message(self, format, *args):
        pass

    def _table(self):
        last_values = state.get_last_values()
        objects = state.get_objects()
        html = ""
        for player_id in range(1000):
            key = str(player_id)
            if key in last_values:
                val = last_values[key]
                obj_type = objects.get(player_id, 'rank')
                if obj_type == 'rank':
                    rank_val = int(val)
                    mmr_val = int(val) * 100
                    hero_val = (player_id % 124) + 1
                    hours_val = float(100 + player_id * 10)
                elif obj_type == 'mmr':
                    mmr_val = int(val)
                    rank_val = max(1, min(80, int(val) // 100))
                    hero_val = (player_id % 124) + 1
                    hours_val = float(100 + player_id * 10)
                elif obj_type == 'hero':
                    hero_val = int(val)
                    rank_val = (player_id % 80) + 1
                    mmr_val = rank_val * 100
                    hours_val = float(100 + player_id * 10)
                else:
                    hours_val = float(val)
                    rank_val = (player_id % 80) + 1
                    mmr_val = rank_val * 100
                    hero_val = (player_id % 124) + 1
            else:
                rank_val = (player_id % 80) + 1
                mmr_val = rank_val * 100
                hero_val = (player_id % 124) + 1
                hours_val = float(100 + player_id * 10)

            rank_class = "rank-high" if rank_val >= 60 else "rank-mid" if rank_val >= 30 else "rank-low"
            html += f'''<tr>
                <td>#{player_id}</td>
                <td class="{rank_class}"><img src="{get_rank_image(rank_val)}" class="rank-img" onerror="this.style.display='none'">{get_rank_name(rank_val)}</td>
                <td>{mmr_val:,}</td>
                <td class="hero-cell"><img src="{get_hero_image(hero_val)}" class="hero-img" onerror="this.style.display='none'">{get_hero_name(hero_val)}</td>
                <td>{hours_val:.1f} ч</td>
            </tr>'''
        return html

    def _html(self):
        return '''<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Дота 2 Статистика</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #e0e0e0; font-family: Arial, sans-serif; padding: 20px; }
        h1 { color: #e94560; text-align: center; margin-bottom: 30px; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 40px; max-width: 1400px; margin: 0 auto 40px; }
        .stat-card { background: #16213e; border: 3px solid #e94560; border-radius: 15px; padding: 25px; text-align: center; }
        .stat-card h2 { color: white; background: #e94560; padding: 10px; border-radius: 8px; margin-bottom: 15px; }
        .stat-value { font-size: 2.5em; font-weight: bold; color: #00ff88; }
        .stat-label { color: #a0a0a0; margin-top: 5px; }
        table { width: 100%; max-width: 1400px; margin: 0 auto; border-collapse: collapse; background: #16213e; }
        th { background: #e94560; color: white; padding: 15px; }
        td { padding: 12px; border-bottom: 1px solid #0f3460; text-align: center; }
        tr:nth-child(even) { background: rgba(26, 26, 46, 0.6); }
        .hero-cell { text-align: left; padding-left: 20px; display: flex; align-items: center; gap: 10px; }
        .hero-img { width: 50px; height: 35px; border-radius: 5px; }
        .rank-img { width: 35px; height: 35px; vertical-align: middle; margin-right: 5px; }
        .rank-high { color: #ffd700; font-weight: bold; }
        .rank-mid { color: #00ff88; }
        .rank-low { color: #ff6b6b; }
        .update-time { text-align: center; margin-top: 20px; color: #a0a0a0; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        .live { animation: pulse 2s infinite; color: #00ff88; }
    </style>
</head>
<body>
    <h1> Дота 2 - Статистика игроков</h1>
    <div class="stats">
        <div class="stat-card"><h2> Ранги</h2><div class="stat-value" id="rank">0</div><div class="stat-label">значений/сек</div></div>
        <div class="stat-card"><h2> ММР</h2><div class="stat-value" id="mmr">0</div><div class="stat-label">значений/сек</div></div>
        <div class="stat-card"><h2>⚔ Герои</h2><div class="stat-value" id="hero">0</div><div class="stat-label">значений/сек</div></div>
        <div class="stat-card"><h2>⏱ Часы</h2><div class="stat-value" id="hours">0</div><div class="stat-label">значений/сек</div></div>
    </div>
    <table><thead><tr><th>ID</th><th>Ранг</th><th>ММР</th><th>Герой</th><th>Часы</th></tr></thead>
    <tbody id="table"></tbody></table>
    <div class="update-time"><span class="live">● LIVE</span> | Обновлено: <span id="time">--:--:--</span> | Записей: <span id="total">0</span></div>
    <script>
        function update() {
            fetch('/api/stats').then(r=>r.json()).then(d=>{
                document.getElementById('rank').textContent=d.rank;
                document.getElementById('mmr').textContent=d.mmr;
                document.getElementById('hero').textContent=d.hero;
                document.getElementById('hours').textContent=d.hours;
                document.getElementById('total').textContent=d.total||0;
                document.getElementById('time').textContent=new Date().toLocaleTimeString();
            });
            fetch('/api/data').then(r=>r.json()).then(d=>{document.getElementById('table').innerHTML=d.html;});
        }
        setInterval(update, 2000);
        update();
    </script>
</body>
</html>'''


def start_server(port=8080):
    server = HTTPServer(('localhost', port), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f" Веб-сервер: http://localhost:{port}")
    return server