import threading


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.objects = {}
        self.last_values = {}
        self.stats = {'rank': 0, 'mmr': 0, 'hero': 0, 'hours': 0, 'total': 0}

    def set_objects(self, objects):
        with self.lock:
            self.objects = objects

    def get_objects(self):
        with self.lock:
            return self.objects.copy()

    def update_value(self, obj_id, value):
        with self.lock:
            self.last_values[str(obj_id)] = value

    def get_last_values(self):
        with self.lock:
            return self.last_values.copy()

    def set_last_values(self, values):
        with self.lock:
            self.last_values = values

    def set_stats(self, rank, mmr, hero, hours):
        with self.lock:
            self.stats['rank'] = rank
            self.stats['mmr'] = mmr
            self.stats['hero'] = hero
            self.stats['hours'] = hours
            self.stats['total'] += rank + mmr + hero + hours

    def get_stats(self):
        with self.lock:
            return self.stats.copy()


state = State()